#!/bin/sh
#### "*******************************************"
#### "              Created By RAED              *"
#### "*        << Edited by  linuxsat25 >>       *"
#### "*        ..:: www.tunisia-sat.com ::..     *"
#### "*******************************************"
# Type: OSCam_11.717-r798

/usr/script/OSCam_11.717-r798_cs.sh stop
sleep 5

rm -rf /usr/bin/OSCam_11.717-r798
rm -rf /usr/script/OSCam_11.717-r798_cs.sh
rm -rf /usr/uninstall/OSCam_11.717-r798_remove.sh
rm -rf /lib/systemd/system/OSCam_11.717-r798.service
rm -rf /lib/systemd/system/OSCam_11.717-r798.socket

exit 0
