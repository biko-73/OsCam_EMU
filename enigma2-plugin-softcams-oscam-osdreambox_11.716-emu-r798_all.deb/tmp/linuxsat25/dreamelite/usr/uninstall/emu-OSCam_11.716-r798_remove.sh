#!/bin/sh
#### "*******************************************"
#### "              Created By RAED              *"
#### "*        << Edited by  linuxsat25 >>       *"
#### "*        ..:: www.tunisia-sat.com ::..     *"
#### "*******************************************"
dpkg -r enigma2-plugin-softcams-OSCam_11.716-r798-osdreambox
exit 0
